
import json
import select
import time
import logging
import os
os.environ["OMP_NUM_THREADS"] = "1"
import threading


from typing import Callable

import gym
import minerl
import abc
import numpy as np

import coloredlogs
coloredlogs.install(logging.DEBUG)

from model import Model
import torch
import cv2

# All the evaluations will be evaluated on MineRLObtainDiamondVectorObf-v0 environment
MINERL_GYM_ENV = os.getenv('MINERL_GYM_ENV', 'MineRLObtainDiamondVectorObf-v0')
MINERL_MAX_EVALUATION_EPISODES = int(os.getenv('MINERL_MAX_EVALUATION_EPISODES', 100))

# Parallel testing/inference, **you can override** below value based on compute
# requirements, etc to save OOM in this phase.
EVALUATION_THREAD_COUNT = int(os.getenv('EPISODES_EVALUATION_THREAD_COUNT', 4))

device = "cuda" if torch.cuda.is_available() else "cpu"


class EpisodeDone(Exception):
    pass

class Episode(gym.Env):
    """A class for a single episode.
    """
    def __init__(self, env):
        self.env = env
        self.action_space = env.action_space
        self.observation_space = env.observation_space
        self._done = False

    def reset(self):
        if not self._done:
            return self.env.reset()

    def step(self, action):
        s,r,d,i = self.env.step(action)
        if d:
            self._done = True
            raise EpisodeDone()
        else:
            return s,r,d,i


class MineRLAgent():
    """
    An example random agent.
    
    """

    def load_agent(self):
        """In this example we make a random matrix which
        we will use to multiply the state by to produce an action!

        This is where you could load a neural network.
        """
        # Some helpful constants from the environment.
        self.model = Model()
        self.model.load_state_dict(torch.load("train/model.tm", map_location=device))
        # self.model.load_state_dict(torch.load("testing/m.tm", map_location=device))

        self.model.to(device)


    def run_agent_on_episode(self, single_episode_env : Episode):
        """Runs the agent on a SINGLE episode.

        Args:
            single_episode_env (Episode): The episode on which to run the agent.
        """
        reward_sum = 0
        with torch.no_grad():
            obs = single_episode_env.reset()
            done = False
            state = self.model.get_zero_state(1, device=device)
            s = torch.zeros((1,1,64), dtype=torch.float32, device=device)
            while not done:

                spatial = torch.tensor(obs["pov"], device=device, dtype=torch.float32).unsqueeze(0).unsqueeze(0).transpose(2,4)
                #cv2.imshow("xdd", obs["pov"])
                # cv2.waitKey(30)
                nonspatial = torch.cat([torch.tensor(obs["vector"], device=device, dtype=torch.float32),
                                        torch.ones((2,), device=device,dtype=torch.float32)], dim=0).unsqueeze(0).unsqueeze(0)
                s, state = self.model.sample(spatial, nonspatial, s, state, torch.zeros((1,1,64),dtype=torch.float32,device=device))

                rewards = []
                for i in range(1):
                    obs,reward,done,_ = single_episode_env.step({"vector":s})
                    reward_sum += reward
                    if reward > 0:
                        rewards.append(reward)
                        print(reward_sum)
                    if done:
                        break

