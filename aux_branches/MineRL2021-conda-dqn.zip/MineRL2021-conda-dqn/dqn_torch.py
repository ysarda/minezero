import minerl
import gym
import torch
import torch.nn as nn
import torch.optim as optim

import matplotlib.pyplot as plt

import numpy as np

from collections import deque 

from models import DQN1
from wrappers import hybridEnv

env = hybridEnv('./missions/treechop.xml')
#env.make_interactive(port=6666, realtime=True)

data = minerl.data.make('MineRLTreechop-v0')
names = data.get_trajectory_names()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
agent = DQN1(64,64,3,5,device).to(device)
optimizer = optim.RMSprop(agent.parameters())

def train(n_episodes= 200, eps_start=1.0, eps_end = 0.1, eps_decay=0.999):
    scores = [] 
    scores_window = deque(maxlen=100) 
    eps = eps_start
    
    for i_episode in range(1, n_episodes+1):
        state = torch.tensor(env.reset())
        score = 0
        step = 0
        done = False
        while not done:
            if torch.rand(1) > eps:
                action = agent.forward(state)
            else:
                action = agent.random_action()
            next_state,reward,done,_ = env.step(action)

            state = next_state
            score += reward
            scores_window.append(score)
            scores.append(score) 
            eps = max(eps*eps_decay,eps_end)
            step += 1
            print('\rEpisode {}\tAverage Score {:.2f}\tTimestep {}\t Epsilon {:.2f}'.format(i_episode,np.mean(scores_window),step,eps), end="")
            
            if step > 10000:
                break
            if np.mean(scores_window)>=32.0:
                print('\nEnvironment solve in {:d} epsiodes!\tAverage score: {:.2f}'.format(i_episode-100, np.mean(scores_window)))
                torch.save(agent.qnetwork_local.state_dict(),'checkpoint.pth')
                break
        name = names[torch.randint(len(names)-1,[1])]
        print('\n')
        print(f'Offline Training on {name}')
        print('\n')
        for state, target, reward, next_state, done in data.load_data(name):
            action = agent.forward(state['pov'])
            target = env._unwrap_action(target).to(device)
            criterion = nn.SmoothL1Loss()
            loss = criterion(action, target)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    return scores

scores = train()

fig = plt.figure()
ax = fig.add_subplot(111)
plt.plot(np.arange(len(scores)),scores)
plt.ylabel('Score')
plt.xlabel('Epsiode #')
plt.show()

