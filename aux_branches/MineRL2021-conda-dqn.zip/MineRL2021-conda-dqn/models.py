import torch
import torch.nn as nn
import torch.nn.functional as F

class DQN1(nn.Module):

    def __init__(self, h, w, c, outputs, device):
        super(DQN1, self).__init__()
        self.conv1 = nn.Conv2d(c, 16, kernel_size=5, stride=2)
        self.bn1 = nn.BatchNorm2d(16)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=5, stride=2)
        self.bn2 = nn.BatchNorm2d(32)
        self.conv3 = nn.Conv2d(32, 32, kernel_size=5, stride=2)
        self.bn3 = nn.BatchNorm2d(32)

        self.device = device

        def conv2d_size_out(size, kernel_size = 5, stride = 2):
            return (size - (kernel_size - 1) - 1) // stride  + 1
        convw = conv2d_size_out(conv2d_size_out(conv2d_size_out(w)))
        convh = conv2d_size_out(conv2d_size_out(conv2d_size_out(h)))
        linear_input_size = convw * convh * 32

        self.arms = nn.Linear(linear_input_size, outputs-2)
        self.head = nn.Linear(linear_input_size,2)

    def forward(self, x):
        x = torch.tensor(x).to(self.device).unsqueeze(0).permute(0,3,1,2).float()
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x))).flatten()
        a = torch.round(torch.sigmoid(self.arms(x)))
        h = self.head(x)
        return torch.cat([h, a])

    def random_action(self):
        h = torch.rand(2)*360
        a = torch.round(torch.rand(3))
        return torch.cat([h, a])