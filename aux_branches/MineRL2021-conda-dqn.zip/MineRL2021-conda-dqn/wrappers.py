import minerl
import torch
import numpy as np
import gym

class hybridEnv(minerl.env.core.MineRLEnv):
    def __init__(self, xml):
        super().__init__(
            xml,
            gym.spaces.Box(low=0, high=255, shape=(64, 64, 3), dtype=np.uint8),
            gym.spaces.Discrete(8),
            None
        )

    def _setup_spaces(self, observation_space, action_space):
        self.observation_space = observation_space
        self.action_space = action_space

    def _process_action(self, action_in) -> str:
        a = action_in.cpu().detach().numpy()
        command_array = [f'forward {a[2]}', f'jump {a[3]}', f'attack {a[4]}', f'camera {a[0]} {a[1]}']
        return "\n".join(command_array)

    def _process_observation(self, pov, info):
        pov = np.frombuffer(pov, dtype=np.uint8)
        pov = pov.reshape((self.height, self.width, self.depth))
        return pov

    def _unwrap_action(self, action_dict):
        a = [action_dict['forward'], action_dict['jump'], action_dict['attack']]
        h = action_dict['camera']
        return torch.cat([torch.tensor(h),torch.tensor(a)])