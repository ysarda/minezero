import minerl
import d3rlpy
import numpy as np

from action_wrappers import ActionUnwrapper as AU

data = minerl.data.make('MineRLTreechop-v0')
names = data.get_trajectory_names()
cql = d3rlpy.algos.CQL(use_gpu=True)

for name in names:
    print(name)
    observations,actions,rewards,terminals = [], [], [], []

    for state, action, reward, next_state, done in data.load_data(name):
        observations.append(np.moveaxis(state['pov'],-1,0))
        action = np.array(AU(action))
        actions.append(action)
        rewards.append(reward)
        terminals.append(done)

    observations = np.array(observations)
    dataset = d3rlpy.dataset.MDPDataset(observations, actions, rewards, terminals)
    cql.fit(dataset.episodes, n_epochs=50, save_metrics=False)

cql.save_model('cql_treechop.pt')

