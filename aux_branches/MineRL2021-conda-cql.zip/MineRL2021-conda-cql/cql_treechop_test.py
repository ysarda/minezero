import minerl
import torch

import d3rlpy
from d3rlpy.algos import CQL
from d3rlpy.online.buffers import ReplayBuffer

import numpy as np
import gym
from action_wrappers import ActionWrapper as AW



env = gym.make('MineRLTreechop-v0')
#env.make_interactive(port=6666, realtime=True)

cql = CQL.from_json('cql_params.json')
cql.load_model('cql_treechop.pt')

state_dict = env.reset()
state = torch.tensor(state_dict['pov']).unsqueeze(0).permute(0,3,1,2)
done = False
totreward = 0

while not done:
    action_temp = env.action_space.noop()
    action_raw = cql.predict(state)
    action = AW(action_raw, action_temp)
    state_dict, reward, done, info = env.step(action)
    state = torch.tensor(state_dict['pov']).unsqueeze(0).permute(0,3,1,2)
    totreward += reward
    print('reward: ',totreward)

