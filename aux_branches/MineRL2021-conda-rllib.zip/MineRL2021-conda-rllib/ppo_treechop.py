import gym, ray
import ray.tune as tune
from ray.rllib.agents import ppo
from menv.wrappers import continousEnv

def create_env(config):
    mission = config["mission"]
    env = continousEnv(mission)
    return env

if __name__ == '__main__':
    
    tune.register_env("chopEnv", create_env)

    ray.init()

    tune.run(
        run_or_experiment="PPO",
        config={
            "env": "chopEnv",
            "env_config": {"mission": "missions/treechop.xml"},
            "num_gpus": 0,
            "framework":"torch",
            "num_workers": 1},

        checkpoint_freq=1,
        checkpoint_at_end=True,
        local_dir='./logs'
    )

    print('training has done !')
    ray.shutdown()