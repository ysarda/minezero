import gym, ray
import ray.tune as tune
from ray.rllib.agents import ppo
from menv.wrappers import discreteEnv

def create_env(config):
    mission = config["mission"]
    env = discreteEnv(mission)
    return env

if __name__ == '__main__':
    
    tune.register_env("chopEnv", create_env)

    ray.init()

    tune.run(
        run_or_experiment="A2C",
        config={
            "env": "chopEnv",
            "env_config": {"mission": "missions/treechop.xml"},
            "num_gpus": 1,
            "framework":"torch",
            "num_workers": 1,
            "model": {
                "conv_filters": [[16, [4, 4], 2], [32, [4, 4], 2], [512, [16, 16], 1]],
                "conv_activation": "relu"
            },
            "train_batch_size": 8,
        },
        checkpoint_freq=1,
        checkpoint_at_end=True,
        local_dir='./logs'
    )

    print('training has done !')
    ray.shutdown()