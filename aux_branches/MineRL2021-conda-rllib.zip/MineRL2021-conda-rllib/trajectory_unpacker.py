import minerl
import numpy as np
from ray.rllib.evaluation.sample_batch_builder import SampleBatchBuilder
from ray.rllib.offline.json_writer import JsonWriter
from menv.actions import discreteUnwrapper as DU

data = minerl.data.make("MineRLTreechop-v0")
names = data.get_trajectory_names()
batch_builder = SampleBatchBuilder()
writer = JsonWriter("./data/")

for name in names[0:1]:
    print(name)

    for state, action, reward, next_state, done in data.load_data(name):
        obs = np.moveaxis(state["pov"],-1,0)
        action = DU(action)

        

    


