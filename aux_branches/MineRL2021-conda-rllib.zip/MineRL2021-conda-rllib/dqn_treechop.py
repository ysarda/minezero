import ray
import ray.tune as tune
from menv.wrappers import discreteEnv

def create_env(config):
    mission = config["mission"]
    env = discreteEnv(mission)
    return env

if __name__ == '__main__':
    
    tune.register_env("chopEnv", create_env)

    ray.init()

    tune.run(
        run_or_experiment="APEX",
        config={
            "env": "chopEnv",
            "env_config": {
                "mission": "./missions/treechop.xml"
            },
            "num_gpus": 1,
            "num_workers": 1,
            "ignore_worker_failures": False,
            "double_q": False,
            "dueling": False,
            "explore": True,
            "exploration_config": {
                "type": "EpsilonGreedy",
                "initial_epsilon": 1.0,
                "final_epsilon": 0.02,
                "epsilon_timesteps": 500000
            },
            "framework": "torch",
            "model": {
                "conv_filters": [[16, [4, 4], 2], [32, [4, 4], 2], [512, [16, 16], 1]],
                "conv_activation": "relu"
            },
            "rollout_fragment_length": 10,
            "train_batch_size": 4,
        },
        checkpoint_freq=10,
        checkpoint_at_end=True,
        local_dir='./logs',
        #restore='/media/banshee/users/yash/MineRL/logs/DQN/DQN_chopEnv_4c1fd_00000_0_2021-07-13_09-21-57/checkpoint_012810/checkpoint-12810'
    )

    print('training has done !')
    ray.shutdown()