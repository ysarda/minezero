import ray
import ray.tune as tune
from menv.wrappers import continousEnv

def create_env(config):
    mission = config["mission"]
    env = continousEnv(mission)
    return env

if __name__ == '__main__':
    
    tune.register_env("chopEnv", create_env)

    ray.init()

    tune.run(
        run_or_experiment="MARWIL",
        config={
            "env": "chopEnv",
            "env_config": {
                "mission": "./missions/treechop.xml"
            },
            "num_gpus": 0,
            "num_workers": 1,
            "ignore_worker_failures": False,
            # "input": {
            #     "./data/treechop.json": 0.5,
            #     "sampler": 0.5
            #     },
            "input_evaluation": ["simulation"],
            "framework": "torch",
            "model": {
                "conv_filters": [[16, [4, 4], 2], [32, [4, 4], 2], [512, [16, 16], 1]],
                "conv_activation": "relu"
            }
        },
        checkpoint_freq=10,
        checkpoint_at_end=True,
        local_dir='./logs'
    )

    print('training has done !')
    ray.shutdown()