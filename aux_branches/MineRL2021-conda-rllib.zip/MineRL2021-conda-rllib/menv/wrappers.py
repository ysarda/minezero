import minerl
import torch
import numpy as np
import gym

class continousEnv(minerl.env.core.MineRLEnv):
    def __init__(self, xml):
        super().__init__(
            xml,
            gym.spaces.Box(low=0, high=255, shape=(64, 64, 3),dtype = np.uint8),
            gym.spaces.Box(low=-1, high=1, shape=(5,)),
            None
        )
    def _setup_spaces(self, observation_space, action_space):
        self.observation_space = observation_space
        self.action_space = action_space

    def _process_action(self, action_in) -> str:
        a = action_in
        command_array = [f'forward {a[0]}', f'jump {a[1]}', f'attack {a[2]}', f'camera {180*a[3]} {180*a[4]}'] 
        return "\n".join(command_array)

    def _process_observation(self, pov, info):
        pov = np.frombuffer(pov, dtype=np.uint8)
        pov = pov.reshape((self.height, self.width, self.depth))
        return pov


class discreteEnv(minerl.env.core.MineRLEnv):
    def __init__(self, xml):
        super().__init__(
            xml,
            gym.spaces.Box(low=0, high=255, shape=(64, 64, 3), dtype=np.uint8),
            gym.spaces.Discrete(8),
            None
        )

    def _setup_spaces(self, observation_space, action_space):
        self.observation_space = observation_space
        self.action_space = action_space

    def _process_action(self, action_in) -> str:
        action_to_command_array = [
            'forward 1',
            'jump 1',
            'attack 1',
            'camera 0 10',  
            'camera 0 -10',
            'camera 10 0',  
            'camera -10 0',
            'camera 0 0']  
        return action_to_command_array[action_in]

    def _process_observation(self, pov, info):
        pov = np.frombuffer(pov, dtype=np.uint8)
        pov = pov.reshape((self.height, self.width, self.depth))
        return pov