
def discreteUnwrapper(action):
    if action['attack'] == 1:
        return 2
    if action['forward'] == 1:
        return 0
    if action['jump'] == 1:
        return 1
    if action['camera'][1] > 0:
        return 3
    else:
        return 4
    return 7