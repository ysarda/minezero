#!/bin/bash

export IMAGE_NAME="aicrowd/neurips2021-minerl-challenge"
export IMAGE_TAG="agent"
