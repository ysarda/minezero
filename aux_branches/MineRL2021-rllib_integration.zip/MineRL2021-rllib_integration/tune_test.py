import minerl
from minerl.env.core import MineRLEnv

import gym

import ray 
import ray.tune as tune
from ray.rllib.agents import ppo
from ray.tune import resources
from ray.tune.registry import register_env

import numpy as np
#env = gym.make('MineRLTreechopVectorObf-v0')
#env.make_interactive(port=6666, realtime=True)

class MineRLEnvWrap(minerl.env.core.MineRLEnv):
    def __init__(self, xml):
        super().__init__(
            xml,
            gym.spaces.Box(low=0, high=255, shape=(84, 84, 3), dtype=np.uint8),
            gym.spaces.Discrete(3),
            None
        )


def create_env(config):
    mission = config["mission"]
    env = MineRLEnvWrap(mission)
    env.make_interactive(port=6666, realtime=True)
    return env

tune.register_env("testenv01", create_env)
ray.init()

tune.run(
    run_or_experiment="DQN",
    config={
            #"log_level": "DEBUG",
            "env": "testenv01",
            "env_config": {
                "mission": "./missions/treechop.xml"
            },
            "num_gpus": 0,
            "num_cpus_per_worker": 1,
            "num_workers": 1,
            "exploration_config": {
                "type": "EpsilonGreedy",
                "initial_epsilon": 1.0,
                "final_epsilon": 0.02,
                "epsilon_timesteps": 500000
            }
        },
    num_samples=2,
    checkpoint_freq=1,
    checkpoint_at_end=True,
    local_dir='./logs',
    max_failures=1,
    resources_per_trial={
        'cpu':2
    }
)

print('training has done !')
ray.shutdown()