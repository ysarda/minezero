import gym
from ray import tune
import minerl.env.core
import minerl.env.comms
import numpy as np


class Trainable(tune.Trainable):
    def setup(self, config):
        """
        Pass in a dict of hyperparameters
        """

    def step(self):
        """
        This is called iteratively
        """
        score = self.objective(self.x, self.a, self.b)

    def objective(self):
        pass



if __name__ == "__main__":
    analysis = tune.run(
        Trainable, 
        stop={'training_iteration': 20},
        config={
            "a": 2, 
            "b": 4
        }
    )

    